from src.scraper import scraper
import asyncio

asyncio.run(scraper())
